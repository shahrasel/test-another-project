<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-Type" content="text/html; charset=iso-8859-1" />
<title>Amar Boi Mela</title>

<link media="all" type="text/css" rel="stylesheet" href="<?php echo getConfigValue ('site_url')?>css/style.css"/>

<style>
	/*
  Title # Amar Boi Mela
  Date  # 28 August 2009
*/

body{ padding:0px; margin:0px; background-color:#CCCCCC; }


#wrap{
      width:1000px;
	  margin:auto;
	  text-align:left;
	  }
	  
#wrap2{
       width:1000px;
	   padding:0px 0px 17px 0px;
	   background-color:#FFFFFF;
	   float:left;
	   position:relative;
	   }
	   
h1{ font-family:Georgia, "Times New Roman", Times, serif; padding:0px; margin:0px; }

h2{ font-family:Georgia, "Times New Roman", Times, serif; padding:0px; margin:0px; }

ul{ padding:0px; margin:0px; }

.input_box{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#717171; text-align:center; width:211px;
            border:1px solid #C5C5C5; border-top:none; height:18px; background-color:#F0F0F0;
		  }
		  
.input_box2{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#000000; text-align:center; width:46px;
             border:1px solid #B9B7B7; height:18px; background-color:#FFFFFF;
		   }		  

.input_box3{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#000000; text-align:center; width:120px;
             border:1px solid #B9B7B7; height:18px; background-color:#FFFFFF;
		   }	
			 
.input_box_275{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#717171; text-align:center; width:275px;
            border:1px solid #C5C5C5;  height:18px; background-color:#F0F0F0;
		  }

.text_area_275{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#717171; width:275px;
            border:1px solid #C5C5C5;  height:40px; background-color:#F0F0F0;
		  }
.select_box_275{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#717171; width:275px;
            border:1px solid #C5C5C5;  height:18px; background-color:#F0F0F0;
		  }

/* ================================= Start Text ============================ */

.prepand{ padding-top:5px; }
.prepand2{ padding-top:1px; }
.prepand3{ padding-top:15px; }
.prepand4{ padding-top:20px; }
.prepand5{ padding-top:25px; }
.prepand6{ padding-top:30px; }
.prepand7{ padding-top:35px; }

.prepand8{ padding-bottom:15px; }
.prepand9{ padding-top:10px; padding-bottom:25px; }

.color{ font-size:7px; }
.color2{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:36px; font-weight:bold; color:#F0FF00; }
.color3{ font-size:30px; }
.color4{ color:#C32D0B; }
.color5{ color:#FF0C00; }
.color6{ color:#FDFFC7; font-weight:normal; }
   .color6 a{ color:#FDFFC7; text-decoration:none; }
      .color6 a:hover{ color:#FAFF75; }

.font{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:15px; font-weight:normal; color:#7D7D7D;
       background:url(http://amarboimela.com/images/abm_phone_icon.gif) left no-repeat; padding-left:17px; padding-top:4px; }

.font2{ font-family:Georgia, "Times New Roman", Times, serif; font-size:18px; font-weight:normal; color:#7D7D7D; 
        background:url(http://amarboimela.com/images/abm_mail_icon.gif) left no-repeat; padding-left:21px;}
	.font2 a{ color:#7D7D7D; text-decoration:none; }
	    .font2 a:hover{ color:#323232; } 
		
		
.font3{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:bold; color:#FFFFFF; }	

.font4{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:bold; color:#ACACAC;
        background:url(http://amarboimela.com/images/abm_site_icon.gif) left no-repeat; padding-left:15px;}	
	.font4 a{ color:#ACACAC; text-decoration:none; }
	   .font4 a:hover{ color:#323232; }	
		
.font5{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:bold; color:#6C5401; }
   .font5 a{ color:#6C5401; text-decoration:none; } 
      .font5 a:hover{ color:#362A01; }

.font6{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:bold; color:#E1E1E1; }
    .font6 a{ color:#E1E1E1; text-decoration:none; }
	   .font6 a:hover{ color:#FFFFFF; }

.font7{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:bold; color:#F2F2F2; }
    .font7 a{ color:#F2F2F2; text-decoration:none; }
	   .font7 a:hover{ color:#FFFFFF; }	
	   
.font8{ font-family:Georgia, "Times New Roman", Times, serif; font-size:17px; font-weight:normal; color:#FFFFFF; }

.font9{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#727272; }
    .font9 a{ color:#727272; text-decoration:none; }
	   .font9 a:hover{ color:#000000; }	
	   
.font10{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#D1D1D1; }
    .font10 a{ color:#D1D1D1; text-decoration:none; }
	   .font10 a:hover{ color:#FFFFFF; }		   	   	
	   
.font11{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:11px; font-weight:bold; color:#666666; }
.font11 a{color:#666666; text-decoration:none;}
.font12{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; font-weight:bold; color:#279BE5; }
.font13{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:bold; color:#C32D0B; }	

.font14{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#4D6185; }
    .font14 a{ color:#4D6185; text-decoration:none; }
	   .font14 a:hover{ color:#0F8D81; }   
	   
.font15{font-family:Georgia, "Times New Roman", Times, serif; font-size:19px; font-weight:normal; color:#F0FF02; }	

.font16{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#FFFFFF; }
    .font16 a{ color:#FFFFFF; text-decoration:none; }
	   .font16 a:hover{ color:#000000; }   
	   
.font17{font-family:Georgia, "Times New Roman", Times, serif; font-size:19px; font-weight:normal; color:#FFFFFF; padding-left:38px; }
.font18{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#8B8B8B; }
.font19{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:bold; color:#666666; }
.font20{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:bold; color:#969696; }	 
  .font20 a{ color:#969696; text-decoration:none; }
	  .font20 a:hover{ color:#000000; }  
	  
.font21{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:bold; color:#507D86; }
.font22{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:bold; color:#129CB9; }
.font22 a{
	color:#129CB9;
}
.font23{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:bold; color:#838282; }
.font23 a{
	color:#838282;
}
.font24{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:bold; color:#808080; }	  
.font25{font-family:Georgia, "Times New Roman", Times, serif; font-size:19px; font-weight:normal; color:#666666; }
.font26{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:17px; font-weight:normal; color:#0C6F94; }	
.font27{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:17px; font-weight:normal; color:#FE4932; }	
.font28{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:bold; color:#0C6F94; }
    .font28 a{ color:#0C6F94; text-decoration:underline; }
	    .font28 a:hover{ color:#049DB9; }	   

/* new dessign */
.font29{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:10px; font-weight:bold; color:#4C7D18; }
.font30{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#60A615; }
	.font30 a{color:#60A615; text-decoration:none; }
		.font30 a:hover{color:#60A615; text-decoration:underline; }
	
	
.font31{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#797979; }
.font32{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#54871F; }
.font33{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:bold; color:#5E848C; }
    .font33 a{color:#5E848C; text-decoration:underline; }
	    .font33 a:hover{color:#797979; text-decoration:none; }
		
.font34{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:bold; color:#68B910; }
    .font34 a{color:#68B910; text-decoration:none; }
	    .font34 a:hover{color:#797979; }	
		
.font35{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#72B825; text-align:right;padding-bottom:30px; }
    .font35 a{ color:#72B825; text-decoration:none; }
	   .font35 a:hover{ color:#0F8D81; }		
		 
/* ================================= End Text ============================= */

/* ================================= Start Top ============================ */

#top{
     width:985px;
	 padding:0px 0px 4px 15px;
	 float:left;
	 position:relative;
	 }
	 
   .phone{
		  width:152px;
		  padding-top:2px;
		  float:left;
		  position:relative;
		  }
			   
	.mail{
		  width:343px;
		  padding:5px 0px 0px 3px;
		  float:left;
		  position:relative;
		  }
		  
	 .advertise{
			   width:192px;
			   padding:4px 0px 5px 0px;
			   background-color:#47B3FF;
			   float:left;
			   position:relative;
			   text-align:center;
			   }
			   
	 .feedback{
			   width:265px;
			   padding:4px 0px 0px 14px;
			   float:left;
			   position:relative;
			   text-align:right;
			   }
			   
#header{
        width:1000px;
		background:url(http://amarboimela.com/images/pae_head_reapeter.jpg) repeat-x;
		height:150px;
		float:left;
		position:relative;
		}
		
.header2{
        width:1000px;
		padding-bottom:18px;
		float:left;
		position:relative;
		}					   		   	  		   	 

    .gift{
          width:95px;
		  padding:4px 0px 6px 0px;
		  background-color:#FFC600;
		  float:left;
		  position:relative;
		  text-align:center;
		  }
		  
	 .delivery{
               width:116px;
			   padding:4px 0px 6px 0px;
			   background-color:#168A7F;
		       float:left;
		       position:relative;
			   text-align:center;
		       }
			  
	  .kid_corner{
				  width:104px;
				  padding:4px 0px 6px 0px;
				  background-color:#65C9EE;
				  float:left;
				  position:relative;
				  text-align:center;
				 }
				 
	   .tweeter_facebook{
	                     width:182px;
						 padding:3px 0px 0px 112px;
						 float:left;
						 position:relative;
						 }
						 
		.signin_sitemap{
		                width:382px;
						background:url(http://amarboimela.com/images/abm_signin_sitemap_bg.png) no-repeat;
						height:25px;
						padding-top:2px;
						float:left;
						position:relative;
						text-align:center;
						}
						
			.signin_sitemap li{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:bold; color:#616161; list-style:none;
			                    display:inline; background:url(http://amarboimela.com/images/abm_line.gif) left no-repeat; padding-left:8px; padding-right:9px;
							  }
				 .signin_sitemap li a{ color:#616161; text-decoration:none; }
				     .signin_sitemap li a:hover{ color:#000000; }		
					 
	.logo{
	      width:460px;
		  padding:0px 0px 0px 33px;
		  float:left;
		  position:relative;
		  }
		  
/* ================================= End Top ============================= */	 


/* ============================== Start Navigation ============================== */

.nav{
     width:1000px;
	 background:url(http://amarboimela.com/images/abm_nav_bg.gif) repeat-x;
	 height:33px;
	 padding-top:6px;
	 float:left;
	 position:relative;
	 text-align:center;
	 }
	 
   .nav li{ font-family:Georgia, "Times New Roman", Times, serif; font-size:21px; font-weight:normal; color:#FFFFFF; list-style:none;
			                    display:inline; background:url(http://amarboimela.com/images/abm_nav_line.gif) left no-repeat; padding-left:25px; padding-right:30px;
							  }
				 .nav li a{ color:#FFFFFF; text-decoration:none; }
				     .nav li a:hover{ color:#F8FC93; }	 

/* ============================== End Navigation ============================== */

/* ============================== Start Menu ============================== */

.menu{
     width:1000px;
	 padding:10px 0px 10px 0px;
	 background-color:#EDEFD1;
	 float:left;
	 position:relative;
	 text-align:center;
	 }
	 
   .menu li{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#636612; list-style:none;
			                    display:inline; background:url(http://amarboimela.com/images/abm_bullett.gif) left no-repeat; padding-left:14px; padding-right:11px;
							  }
				 .menu li a{ color:#636612; text-decoration:none; }
				     .menu li a:hover{ color:#0F857A; }	 

/* ============================== End Menu ============================== */  


/* ===================================================== Start Main Body ==================================================================== */

#body_block{
           width:948px;
		   padding:5px 26px 19px 26px;
		   float:left;
		   position:relative;
		   }

.main_body2{
           width:769px;
		   padding:20px 0px 0px 179px;
		   float:left;
		   position:relative;
		   }
		   
		.search_box{
		            width:475px;
					/*background:url(http://amarboimela.com/images/abm_search_box_bg.jpg) repeat-x;*/
					height:32px;
					padding-top:6px;
					text-align:center;
					float:left;
					padding-left:70px;
					position:relative;
					}
					
.main_body3{
           width:948px;
		   padding:0px 0px 20px 0px;
		   float:left;
		   position:relative;
		   }
		   
		.banner{
		        width:649px;
				padding:17px 15px 0px 17px;
				background:url(http://amarboimela.com/images/abm_banner.jpg) no-repeat;
				height:147px;
				float:left;
				position:relative;
				}
				
				.banner h1{ font-family:Georgia, "Times New Roman", Times, serif; font-size:29px; font-weight:normal; color:#FFFEC9; }  
				
		 .banner2{
		        width:247px;
				padding-left:18px;
				background:url(http://amarboimela.com/images/abm_banner2.jpg) no-repeat;
				height:154px;
				padding-top:10px;
				float:right;
				position:relative;
				}
				
				.banner2 h1{ font-family:Georgia, "Times New Roman", Times, serif; font-size:25px; font-weight:normal; color:#FFFEC9; }	
				
.main_body4{
           width:948px;
		   float:left;
		   position:relative;
		   }				
				
.top_sellers{
           width:918px;
		   padding:5px 16px 0px 14px;
		   background:url(http://amarboimela.com/images/abm_top_sellers_bg.jpg) no-repeat;
		   height:31px;
		   float:left;
		   position:relative;
		   }
		   
		   .top_sellers h2{ font-family:Georgia, "Times New Roman", Times, serif; font-size:21px; font-weight:normal; color:#FFFFFF;
						    background:url(http://amarboimela.com/images/abm_bullett4.jpg) left no-repeat; padding-left:18px;
						  }
		   
		 .top_sellers_left{
						   width:412px;
						   float:left;
						   position:relative;
						   }
						   
			 .top_sellers_left h2{ font-family:Georgia, "Times New Roman", Times, serif; font-size:21px; font-weight:normal; color:#FFFFFF;
			                       background:url(http://amarboimela.com/images/abm_bullett4.jpg) left no-repeat; padding-left:18px;
								 }			   
						   
		.top_sellers_mid{
						 width:110px;
						 padding-top:2px;
						 float:left;
						 position:relative;
						 }
						 
.number{
padding: 0px;
/*width:110px;*/
}

.number ul{
margin: 0px;
padding: 0;
text-align: left; /*Set to "right" to right align pagination interface*/
font-size: 16px;
}

.number li{
list-style-type: none;
display: inline;
padding-bottom: 1px;
}

.number a, .number a:visited{
padding: 0 5px;
text-decoration: none; 
color: #FFFFFF;
}

.number a:hover, .number a:active{
border:none;
color: #FFFFFF;
background-color: #2F9087;
}

.number a.currentpage{
background-color: #2F9087;
color: #FFF !important;
border:1px solid #ADB6B5;
font-weight: bold;
cursor: default;
}

.number a.disablelink, .number a.disablelink:hover{
background-color: white;
cursor: default;
color: #929292;
border-color: #929292;
font-weight: normal !important;
}

.number a.prevnext{
font-weight: bold;
}	 	
						 
		.top_sellers_right{
						   width:23px;
						   padding-top:3px;
						   float:right;
						   position:relative;
						   }				 			     
		   
.top_sellers_body{
			     width:921px;
				 padding:15px 12px 4px 13px;
				 border-left:1px solid #E0DEDE;
				 border-right:1px solid #E0DEDE;
			     float:left;
			     position:relative;
			     }
.cms_body{
			     width:921px;
				 padding:15px 12px 14px 13px;
				 border:1px solid #E0DEDE;
				 /*border-right:1px solid #E0DEDE;*/
			     float:left;
			     position:relative;
			     }
		
		.cms_body a{
			color:#666666;
		}
		
	  .top_sellers_body2{
						 width:919px;
						 padding-bottom:14px;
						 background-color:#FDFFC7;
						 border:1px solid #E5E5E5;
						 float:left;
						 position:relative;
						 }
						 
				.top_sellers_body2a{
									width:919px;
									background:url(http://amarboimela.com/images/abm_top_sellers_bg2.gif) repeat-x;
									height:31px;
									float:left;
									position:relative;
									}
									
					  .top_sellers_text{
										padding:8px 15px 0px 15px;
										height:23px;
										float:left;
										position:relative;
										border-left:#999 solid 1px;border-right:#999 solid 1px;cursor:pointer;
										}
										
						.top_sellers_text h2{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:11px; font-weight:bold; color:#585858; }							 		 		   										   	    	   		   
		   		   
				     .top_sellers_text2{
										padding:8px 15px 0px 15px;
										background:url(http://amarboimela.com/images/abm_top_sellers_bg2a.gif) repeat-x;
										height:23px;
										float:left;
										border-right:#999 solid 1px;
										position:relative;
										}
						.top_sellers_text2 h2{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; font-weight:bold; color:#585858; }
						
					.top_sellers_line{
									  width:1px;
									  padding-top:6px;
									  float:left;
									  position:relative;
									  }
									  
				.top_sellers_body2b{
									width:919px;
									padding:13px 0px 0px 0px;
									float:left;
									position:relative;
									}
							
							.book{
								  width:150px;
								  text-align:center;
								  float:left;
								  position:relative;
									height:325px;
								  }	
								  
							.book2{
								  width:150px;
								  text-align:center;
								  border-left:2px solid #E4E5CF;
								  float:left;
								  position:relative;
									height:325px;
								  }
								  
							.book3{
								  width:151px;
								  text-align:center;
								  border-left:2px solid #E4E5CF;
								  float:left;
								  position:relative;
								  }	
								  
							.left_arrow{
							            width:28px;
										left:0px;
										top:182px;
										float:left;
										position:absolute;
										z-index:1000;
										}
										
							.right_arrow{
							            width:27px;
										left:919px;
										top:182px;
										float:left;
										position:absolute;
										z-index:10000000;
										}
										
		.top_sellers_body3{
						 width:919px;
						 padding-top:12px;
						 float:left;
						 position:relative;
						 }								
										
			.book4{
				  width:183px;
				  padding-left:30px;
				  float:left;
				  position:relative;
				  }
				  
				  .book4 h2{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:bold; color:#6F6F6F; }
				  
				  .book4 ul{ padding-left:9px; padding-top:8px; }
				  
				  .book4 li{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#0F8D81; list-style:none;
			                 background:url(http://amarboimela.com/images/abm_bullett5.gif) left no-repeat; padding-left:11px; line-height:21px;
						   }
					 .book4 li a{ color:#0F8D81; text-decoration:none; }
						 .book4 li a:hover{ color:#6F6F6F; }
				  
			.music{
				  width:119px;
				  padding-left:14px;
				  border-left:1px solid #E4E5CF;
				  float:left;
				  position:relative;
				  }
				  
				  .music h2{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:bold; color:#6F6F6F; }
				  
				  .music ul{ padding-left:9px; padding-top:8px; }
				  
				  .music li{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#0F8D81; list-style:none;
			                 background:url(http://amarboimela.com/images/abm_bullett5.gif) left no-repeat; padding-left:11px; line-height:21px;
						   }
					 .music li a{ color:#0F8D81; text-decoration:none; }
						 .music li a:hover{ color:#6F6F6F; }
				  
			.movie{
				  width:155px;
				  padding-left:17px;
				  border-left:1px solid #E4E5CF;
				  float:left;
				  position:relative;
				  }
				  
				  .movie h2{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:bold; color:#6F6F6F; }
				  
				  .movie ul{ padding-left:9px; padding-top:8px; }
				  
				  .movie li{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#0F8D81; list-style:none;
			                 background:url(http://amarboimela.com/images/abm_bullett5.gif) left no-repeat; padding-left:11px; line-height:21px;
						   }
					 .movie li a{ color:#0F8D81; text-decoration:none; }
						 .movie li a:hover{ color:#6F6F6F; }
				  
			.magazine{
					  width:183px;
					  padding-left:16px;
					  border-left:1px solid #E4E5CF;
					  float:left;
					  position:relative;
					  }
					  
				  .magazine h2{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:bold; color:#6F6F6F; }
				  
				  .magazine ul{ padding-left:9px; padding-top:8px; }
				  
				  .magazine li{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#0F8D81; list-style:none;
			                 background:url(http://amarboimela.com/images/abm_bullett5.gif) left no-repeat; padding-left:11px; line-height:21px;
						   }
					 .magazine li a{ color:#0F8D81; text-decoration:none; }
						 .magazine li a:hover{ color:#6F6F6F; }
					  
					  
			.bargain_books{
						  width:184px;
						  padding-left:14px;
						  border-left:1px solid #E4E5CF;
						  float:left;
						  position:relative;
						  }
						  
				  .bargain_books h2{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:bold; color:#6F6F6F; }
				  
				  .bargain_books ul{ padding-left:9px; padding-top:8px; }
				  
				  .bargain_books li{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#0F8D81; 
				                     list-style:none; background:url(http://amarboimela.com/images/abm_bullett5.gif) left no-repeat; padding-left:11px; line-height:21px;
						           }
					 .bargain_books li a{ color:#0F8D81; text-decoration:none; }
						 .bargain_books li a:hover{ color:#6F6F6F; }		  		  	  	  	  							
										
																								    		  						  					
.main_body5{
           width:948px;
		   padding-top:5px;
		   float:left;
		   position:relative;
			 
		   }
		   
	.main_body_left{
				   width:639px;
				   float:left;
				   position:relative;
				   }
			
			.abm_category{
					     width:276px;
					     padding:5px 9px 0px 14px;
					     background:url(http://amarboimela.com/images/abm_category_top.jpg) no-repeat;
					     height:26px;
					     float:left;
					     position:relative;
					     }
					.abm_category_body ul{
						width:268px; line-height:23px;
					}
					
					.abm_category_body ul li {
						padding-left:15px; list-style-image:url(http://amarboimela.com/images/abm_cat_bullet.jpg);
list-style-position:inside; list-style-type:disc;color:#0f8d81;
					}
					
					.abm_category_body ul li a{
						text-decoration:none;
						color:#0f8d81;
					}
					
					.abm_category h2{ font-family:Georgia, "Times New Roman", Times, serif; font-size:21px; font-weight:normal; color:#FFFFFF;
									    background:url(http://amarboimela.com/images/abm_bullett4.jpg) left no-repeat; padding-left:18px;
									  }
					.abm_category_body{
								 width:290;
								 padding:15px 14px 4px 13px;
								 border-left:1px solid #E0DEDE;
								 border-right:1px solid #E0DEDE;
								 float:left;
								 position:relative;
								 }
								 
								 .abm_category_body2{
										 width:268px;
										 padding-bottom:14px;
										 background-color:#FDFFC7;
										 border:1px solid #E5E5E5;
										 float:left;
										 position:relative;
										 }
														 
								.abm_category_body2b{
												  width:297px;
												  padding:13px 0px 0px 0px;
												  float:left;
												  position:relative;
												  }
								.abm_category_bottom{
												 width:299px;
												 float:right;
												 position:relative;
												 }
													
		  .bam_recommends{
					     width:616px;
					     padding:5px 9px 0px 14px;
					     background:url(http://amarboimela.com/images/abm_bam_recommends_bg.jpg) no-repeat;
					     height:31px;
					     float:left;
					     position:relative;
					     }
							 
						 
			   .bam_recommends2{
							   width:306px;
							   float:left;
							   position:relative;
							   }			 
		   
				   .bam_recommends2 h2{ font-family:Georgia, "Times New Roman", Times, serif; font-size:21px; font-weight:normal; color:#FFFFFF;
									    background:url(http://amarboimela.com/images/abm_bullett4.jpg) left no-repeat; padding-left:18px;
									  }
									  
			  .bam_recommends_body{
								 width:610px;
								 padding:15px 14px 4px 13px;
								 border-left:1px solid #E0DEDE;
								 border-right:1px solid #E0DEDE;
								 float:left;
								 position:relative;
								 }
								 
					.bam_recommends_body2{
										 width:608px;
										 padding-bottom:14px;
										 background-color:#FDFFC7;
										 border:1px solid #E5E5E5;
										 float:left;
										 position:relative;
										 }
										 
							.bam_recommends_body2a{
												 width:608px;
												 background:url(http://amarboimela.com/images/abm_top_sellers_bg2.gif) repeat-x;
									             height:31px;
												 float:left;
												 position:relative;
												 }
												 
							.bam_recommends_body2b{
												  width:608px;
												  padding:13px 0px 0px 0px;
												  float:left;
												  position:relative;
												  }
												  
									.book5{
										  width:148px;
										  text-align:center;
										  border-left:2px solid #E4E5CF;
										  float:left;
										  position:relative;
										  }
										  

										
							.right_arrow2{
							            width:27px;
										left:611px;
										top:182px;
										float:left;
										position:absolute;
										z-index:10000;
										}				  			  					 			 			 
				 						  		   
				   
	.main_body_right{
				   width:284px;
				   float:right;
				   position:relative;
				   }
	.main_body_right1{
				   width:299px;
				   float:right;
				   position:relative;
				   }
				   
				   .banner3{
				           width:266px;
						   padding-left:18px;
						   background:url(http://amarboimela.com/images/abm_banner3.jpg) no-repeat;
						   height:180px;
						   padding-top:17px;
						   float:left;
						   position:relative;
						   }
						   
						   .banner3 h2{ font-family:Georgia, "Times New Roman", Times, serif; font-size:41px; font-weight:normal; color:#FFFFFF; }
						   
					.banner4{
				           width:147px;
						   padding:22px 15px 0px 122px;
						   background:url(http://amarboimela.com/images/abm_banner4.jpg) no-repeat;
						   height:175px;
						   float:left;
						   position:relative;
						   margin-top:0px;
						   }
						   
						   .banner4 h1{ font-family:Georgia, "Times New Roman", Times, serif; font-size:37px; font-weight:normal; color:#37A60C;
						                line-height:30px; }	   			   	   									

/* ===================================================== End Main Body ==================================================================== */


/* ==================================================== Start Bottom ======================================================================= */

#bottom{
	   width:948px;
	   padding:0px 26px 0px 26px;
	   float:left;
	   position:relative;
	   }
	   
#bottom2{
	   width:948px;
	   border-top:1px solid #D9D9D9;
	   float:left;
	   position:relative;
	   }	   			   
		   
.bottom_right{
		   width:406px;
		   padding-top:5px;
		   float:right;
		   position:relative;
		   }
		   
	.bottom_right li{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#049DB9; list-style:none;
			                    display:inline; background:url(http://amarboimela.com/images/abm_bullett2.gif) left no-repeat; padding-left:12px; padding-right:6px;
							  }
				 .bottom_right li a{ color:#049DB9; text-decoration:none; }
				     .bottom_right li a:hover{ color:#024675; }
					 
	.bottom_font3{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#727272; padding-top:6px;
	              text-align:right; padding-right:9px; }
	   .bottom_font3 a{ color:#727272; text-decoration:none; }
	      .bottom_font3 a:hover{ color:#1C1C1C; }				 	   
		   	   		   	   

/* ==================================================== End Bottom ======================================================================= */


/* ================================================== Start Details Page ================================================================= */

.details_left{
              width:321px;
			  padding-top:22px;
			  float:left;
			  position:relative;
			  }
			  
.details_right{
              width:580px;
			  padding-top:30px;
			  float:left;
			  position:relative;
			  }
			  
		.details_right h1{ font-family:Georgia, "Times New Roman", Times, serif; font-size:21px; font-weight:normal; color:#0C6F94; }		  
			  
	.details_right2{
				  width:540px;
				  padding:16px 0px 17px 28px;
				  background-color:#FDFEE2;
				  border:1px solid #E6E8B8;
				  float:left;
				  position:relative;
				  }
				  
	.details_right3{
              width:540px;
			  padding:22px 30px 0px 0px;
			  text-align:right;
			  float:left;
			  position:relative;
			  }			  		  			  

/* =================================================== End Details Page ================================================================== */


/* ================================================= Start Card ===================================================================== */

.card{
	 width:879px;
	 padding:15px 19px 0px 21px;
	 float:left;
	 position:relative;
	 }
	 
.card_details_body{
				 width:899px;
				 padding:17px 10px 0px 10px;
				 float:left;
				 position:relative;
				 }	 
	 
	.card_details_top{
					 width:881px;
					 padding-left:18px;
					 background:url(http://amarboimela.com/images/abm_card_details_top_bg.jpg) no-repeat;
					 height:29px;
					 padding-top:6px;
					 float:left;
					 position:relative;
					 }
					 
	.card_details_mid{
					 width:881px;
					 padding:12px 0px 0px 18px;
					 float:left;
					 position:relative;
					 }
					 
		 .card_details_mid2{
						   width:864px;
						   padding-bottom:12px;
						   float:left;
						   position:relative;
						   }
						   
		.card_details_mid3{
						   width:864px;
						   padding:12px 0px 12px 0px;
						   border-top:1px solid #D1CECE;
						   float:left;
						   position:relative;
						   }
						   
		.card_details_mid4{
						   width:857px;
						   padding:14px 30px 12px 32px;
						   background-color:#FFFFFF;
						   float:left;
						   position:relative;
						   }
						   
				.card_details_mid4a{
								   width:632px;
								   padding-right:60px;
								   float:left;
								   position:relative;
								   }
								   
				.card_details_mid4b{
								   width:165px;
								   float:left;
								   position:relative;
									 text-align:right;
								   }
									 
				.card_details_mid4c{
								   width:502px;
								   padding-right:60px;
								   float:left;
								   position:relative;
								   }
				.card_details_mid4d{
								   width:120px;
								   padding-right:10px;
								   float:left;
								   position:relative;
								   }					 
								   
		.card_details_mid5{
						   width:889px;
						   padding:22px 30px 0px 0px;
						   text-align:right;
						   float:left;
						   position:relative;
						   }						   				   		   				   				   			 				 	 
	  
/* ================================================= End Card ===================================================================== */

/* slider */
#top_slider{}	
#top_slider ul, #top_slider li{
	margin:0;
	padding:0;
	list-style:none;
}

#top_slider li{ 
	
	width:919px;
	height:330px;
	overflow:hidden; 
}	

#abm_slider{}	
#abm_slider ul, #abm_slider li{
	margin:0;
	padding:0;
	list-style:none;
}

#abm_slider li{ 
	
	width:608;
	height:330px;
	overflow:hidden; 
}	

ul#topcontroll{
	margin: 0;
	padding:0;
	height:20px;	
	}
ul#topcontroll li{
	margin:0 5px 0 0; 
	padding:0;
	float:left;
	list-style:none;
	height:20px;
	line-height:0px;
	}
ul#topcontroll li a{
	float:left;
	height:20px;
	line-height:20px;
	/*border:1px solid #ccc;
	background:#DAF3F8;
	color:#555;*/
	padding:0 5px;
	text-decoration:none;
	}
ul#topcontroll li.current a{
	/*background:#5DC9E1;
	color:#fff;*/
	background-color:#2F9087;
	border:1px solid #ADB6B5;
	color:#FFFFFF !important;
	cursor:default;
	font-weight:bold;
	}
ul#topcontroll li a:focus, #prevBtn a:focus, #nextBtn a:focus{outline:none;}

ul#abmcontroll{
	margin: 0;
	padding:0;
	height:20px;	
	}
ul#abmcontroll li{
	margin:0 5px 0 0; 
	padding:0;
	float:left;
	list-style:none;
	height:20px;
	line-height:0px;
	}
ul#abmcontroll li a{
	float:left;
	height:20px;
	line-height:20px;
	/*border:1px solid #ccc;
	background:#DAF3F8;
	color:#555;*/
	padding:0 5px;
	text-decoration:none;
	}
ul#abmcontroll li.current a{
	/*background:#5DC9E1;
	color:#fff;*/
	background-color:#2F9087;
	border:1px solid #ADB6B5;
	color:#FFFFFF !important;
	cursor:default;
	font-weight:bold;
	}
ul#abmcontroll li a:focus, #prevBtn a:focus, #nextBtn a:focus{outline:none;}

.err_div{
	color:#F00;
	padding-top:5px;
}
.msg_div{
	color:#0F6;
	padding-top:5px;
}

/* ================================================== Start Search Page ================================================================= */

.search_left{
             width:663px;
			 background-color:#FDFFC7;
			 border:1px solid #E5E5E5;
			 float:left;
			 position:relative;
			 }
			 
	 .search_left_top{
					 width:663px;
					 background:url(http://amarboimela.com/images/abm_search_top_bg.gif) repeat-x;
					 height:35px;
					 float:left;
					 position:relative;
					 }
				 
			 .search_top2{
						 width:216px;
						 padding-top:8px;
						 text-align:center;
						 float:left;
						 position:relative;
						 }
						 
			 .search_top3{
						 width:180px;
						 padding-top:11px;
						 float:left;
						 position:relative;
						 }
						 
			.search_top4{
						 width:187px;
						 padding-top:6px;
						 float:left;
						 position:relative;
						 }
						 
			.search_top5{
						 width:66px;
						 padding-top:5px;
						 float:left;
						 position:relative;
						 }
						 		 			 			 			 	 
				 
	  .search_mid{
				 width:625px;
				 padding:15px 17px 0px 21px;
				 float:left;
				 position:relative;
				 }
				 
			 .search_mid2{
						 width:625px;
						 padding-bottom:30px;
						 float:left;
						 position:relative;
						 }
						 
			.search_mid3{
						 width:625px;
						 padding:24px 0px 30px 0px;
						 border-top:1px solid #B7EA80;
						 float:left;
						 position:relative;
						 }			 	 			 		 
			 
			 
					.search_mid3a{
								   width:142px;
								   float:left;
								   position:relative;
								   }
								   
					.search_mid3b{
								   width:306px;
								   padding:0px 20px 0px 0px; 
								   float:left;
								   position:relative;
								   }
								   
					.search_mid3b h2{ font-family:Georgia, "Times New Roman", Times, serif; font-size:21px; font-weight:normal; color:#54871F; } 
					
					.search_mid3b h2 a{
						color:#54871F;
						text-decoration:none;
					}
						.search_mid3b h2 a:hover{
						color:#54871F;
						text-decoration:underline;
					}
								   
					.search_mid3c{
								   width:157px;
								   text-align:right;
								   float:left;
								   position:relative;
								   }
				   
	
	.search_right{
				 width:236px;
				 background-color:#FDFFC7;
				 border:1px solid #E5E5E5;
				 float:right;
				 position:relative;
				 }
				 
		  .search_right_top{
							width:227px;
							padding:5px 0px 0px 9px;
							background:url(http://amarboimela.com/images/abm_search_top_bg.gif) repeat-x;
							height:30px;
							float:left;
							position:relative;
							}
							
					.search_right_top h2{ font-family:Georgia, "Times New Roman", Times, serif; font-size:19px; font-weight:normal; color:#4E8019;
									      background:url(http://amarboimela.com/images/abm_bullett6.jpg) left no-repeat; padding-left:16px;
									    }	
										
		.search_right_mid{
						 width:209px;
						 padding:6px 13px 22px 14px;
						 float:right;
						 position:relative;
						 }	
						 
	 .search_right_mid h2{ font-family:Georgia, "Times New Roman", Times, serif; font-size:13px; font-weight:bold; color:#6F6F6F; }					 
						 
	.search_right_mid ul{ padding-left:11px; padding-top:5px; }
	  
	  .search_right_mid li{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px; font-weight:normal; color:#0F8D81; list-style:none;
				            background:url(http://amarboimela.com/images/abm_bullett5.gif) left no-repeat; padding-left:11px; line-height:23px; position:relative;
				            background-position:0 .8em;
			              }
		 .search_right_mid li a{ color:#0F8D81; text-decoration:none; }
			 .search_right_mid li a:hover{ color:#6F6F6F; }		 										 			   			   			   		 			 

/* ================================================== End Search Page ================================================================= */


.search_tab{
	
	float:left;
	padding:0 0 10px;
	position:relative;
	padding-left:180px;
	width:700px;
}
.search_tab .search_tab_left{
	float:left;
	background:url(http://amarboimela.com/images/search_tab_left.png) left no-repeat; width:5px; height:34px;
}

.search_tab .search_tab_right{
	float:left;
	background:url(http://amarboimela.com/images/search_tab_right.png) left no-repeat; width:5px; height:34px;
}

.search_tab .search_tab_middle{
	float:left;
	background:url(http://amarboimela.com/images/search_tab_middle.png) left repeat-x; width:580px; height:34px;
}

/* paging  */



.pagenav ul.pagelist{
	margin: 0px auto;
  width: auto !important;
	height:auto;
	
	list-style-image:none;
	list-style-position:outside;
	list-style-type:none;
}

.pagenav ul.pagelist li{
	margin-left:2px;
	display:inline;
  float: none !important;
}

.pagenav ul.pagelist li span{
	color:#6A6A6A;

	font-size:14px;
}
.pagenav ul.pagelist li a{
	padding:4px 7px;
	/*float:left;*/
	background:#FFF;
	height:21px;
	font:12px/21px Arial, sans-serif;
	color:#1370b8;
	text-decoration:none;
	border:1px #ddd solid;
}


.pagenav ul.pagelist li a:hover{
	background:#CCC;
	border:1px #ccc solid;
}

.pagenav ul.pagelist li.active {
	padding: 0 7px;
	border-color:#fff;
	color:#8DC24A;
  font-weight: bold;
}

.pagenav ul.pagelist li.prev a{
	padding-left:8px;
}

.pagenav ul.pagelist li.next a{
	padding-right:8px;
}

/*#content ul.pagelist li.prev a{color:#666;}*/

.pagenav ul.pagelist li.prev a,
.pagenav ul.pagelist li.next a{
	border-color:#fff;
}

.pagenav ul.pagelist li a:hover{text-decoration:underline;}

.input_205{
	width:205px;
	height:21px;
	text-align:left;
}

</style>

</head>

<body>
<div align="center">
  <div id="wrap">
    <div id="wrap2">
      <div id="header">
        <div class="header2">
          <div class="gift"> <span class="font5"><a href="<?php echo getConfigValue ('site_url')?>buy giftcard.html">Gift Card</a></span> </div>
          <div class="delivery"> <span class="font6"><a href="<?php echo getConfigValue ('site_url')?>send giftcertificate.html">Gift Certificate</a></span> </div>
          <div class="kid_corner"> <span class="font7"><a href="<?php echo getConfigValue ('site_url')?>kids corner.html">Kids Corner</a></span> </div>
          <div class="tweeter_facebook">
          
          </div>
          <div class="signin_sitemap">
            
            <ul>
            	
              <li style="background:none;"><a href="<?php echo getConfigValue ('site_url')?>signin.html">Sign In</a></li>
              
              <li><a href="<?php echo getConfigValue ('site_url')?>my-account.html">My Account</a></li>
              <li><a href="<?php echo getConfigValue ('site_url')?>view order.html">View Order</a></li>
              <li><a href="<?php echo getConfigValue ('site_url')?>credit.html">Credit</a></li>
              
            </ul>
            
          </div>
        </div>
        
        <div style="float:left; width:1000px;">
          
          <div class="logo"><a href="<?php echo getConfigValue ('site_url')?>index.html"><img src="<?php echo getConfigValue ('site_url')?>images/abm_logo.png" alt="" border="0" /></a></div>
          
                    
          <div style="float:right; padding-top:67px; padding-right:10px;" class="cart_summery">
	          <div style="float:right; width:100px;"> 
            	
              <a href="<?php echo getConfigValue ('twitter_url')?>" target="_blank"><img src="<?php echo getConfigValue('site_url');?>images/abm_tweeter_icon.jpg" alt="" border="0" /></a>&nbsp;<a href="<?php echo getConfigValue ('facebook_url')?>" target="_blank"><img src="<?php echo getConfigValue('site_url');?>images/abm_fb_icon.jpg" alt="" border="0" /></a>&nbsp;<a href="<?php echo getConfigValue ('flicker_url')?>" target="_blank"><img src="<?php echo getConfigValue('site_url');?>images/abm_fr_icon.jpg" alt="" border="0" /></a>
            </div>
          </div>
          
        </div>
      </div>
      
      <!-- Main Menu -->
      <div class="nav">
        <div style="float:left; width:1000px;">
          <ul style="width: 1000px;">
            <li style="background:none;"><a href="<?php echo getConfigValue ('site_url')?>index.html">Home</a></li>
            <li><a href="<?php echo getConfigValue ('site_url')?>books.html">Books</a></li>
            <li><a href="<?php echo getConfigValue ('site_url')?>contact us.html">Contact Us</a></li>
            <li><a href="<?php echo getConfigValue ('site_url')?>faq.html">FAQ</a></li>
            <li><a href="<?php echo getConfigValue ('site_url')?>sitemap.html">Sitemap</a></li>
          </ul>
        </div>
        
      </div>
      <!-- Main Menu -->
      
      <!-- Secondary Menu -->
      <div class="menu">
        <ul>
        	
          <li style="background:none;"><a href="<?php echo getConfigValue ('site_url')?>books.html">Browse Books</a></li>
          <li><a href="<?php echo getConfigValue ('site_url')?>books/bests-elling.html">Bestselling</a></li>
          <li><a href="<?php echo getConfigValue ('site_url')?>books/coming-soon.html">Coming Soon</a></li>
          <li><a href="<?php echo getConfigValue ('site_url')?>category/audio books.html">Audio Books</a></li>
          <li><a href="<?php echo getConfigValue ('site_url')?>category/children books.html">Children Books</a></li>
          <li><a href="<?php echo getConfigValue ('site_url')?>category/used books.html">Used Books</a></li>          
          
        </ul>
      </div>
      <!-- Secondary Menu -->
      
      <div id="body_block">
        
        <?php echo $mail_content;?>
        
        <br style="clear:both" />
        <div style="width:912px; height:10px ">&nbsp;</div>
        
      </div>
      
      
      <div id="bottom">
        <!-- Bottom -->
        <div id="bottom2">
          <div class="bottom_right">
            <ul>
              <li style="padding-left:0px; background:none;"><a href="<?php echo getConfigValue ('site_url')?>terms.html">Terms and Conditions</a></li>
              <li><a href="<?php echo getConfigValue ('site_url')?>privacy.html">Privacy policy</a></li>
              <li><a href="<?php echo getConfigValue ('site_url')?>advertise.html">Advertise with Us</a></li>
            </ul>
            <div class="bottom_font3">Copyright &copy; <a href="http://www.AmarBoiMela.com" target="_blank">AmarBoiMela.com</a>, 2009. all rights reserved.</div>
          </div>
        </div>
        <!-- Bottom -->
      </div>
      
    </div>
  </div>
</div>
</body>
</html>