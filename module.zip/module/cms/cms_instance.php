<?php
require_once ('cms.php');

//$protocols = array('Math', 'Content');
//initProtocols ($protocol_path, $protocols);

class cms_instance extends cms
{ 
		
}

?>