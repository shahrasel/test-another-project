
<form action="<?php echo urlForAdmin('user/login')?>" method="post" enctype="multipart/form-data" >

	User Name: <input type="text" id="login_name" name="login_name" /> <br/><br/>
	Password&nbsp;&nbsp;&nbsp;: <input type="password" id="login_password" name="login_password" /> <br/><br/>
	<input type="submit" value="submit" id="submit" name="submit"/>
		
</form>	
