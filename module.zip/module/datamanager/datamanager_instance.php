<?php
require_once ('datamanager.php');

//$protocols = array('Math', 'Content');
//initProtocols ($protocol_path, $protocols);

class datamanager_instance extends datamanager
{ 
		
}

?>