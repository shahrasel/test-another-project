<link rel="shortcut icon" href="<?php echo getConfigValue('base_url');?>favicon/favicon.ico" type="image/x-icon" /> 

<title><?php echo getGlobalValue('page_title');?></title>
<meta name="Description" content="<?php echo getGlobalValue('meta_description');?>" />
<meta name="keywords" content="<?php echo getGlobalValue('meta_keyword');?>" />
<!--<meta name="google-site-verification" content="smadfCUY0enL26OgD2s7gkIMlaN2Bb2Bp3jv1Z2XGpQ" />

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-16478312-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>-->