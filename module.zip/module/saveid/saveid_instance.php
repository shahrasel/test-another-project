<?php
require_once ('saveid.php');

class saveid_instance extends saveid 
{	
		
}
?>