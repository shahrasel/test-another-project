<?php
require_once ('userrole.php');

class userrole_instance extends userrole 
{	
		
}
?>