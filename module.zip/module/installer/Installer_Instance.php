<?php
require_once ('Installer.php');

//$protocols = array('Math', 'Content');
//initProtocols ($protocol_path, $protocols);

class Installer_instance extends Installer
{ 
		
}

?>