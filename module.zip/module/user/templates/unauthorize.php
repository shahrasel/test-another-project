<div id="wrapper_login">
  <div id="main_body_login">
    <div class="main_body_1_login">
      <div class="main_body_2_login" style="height:351px;">
        
        <h2 class="login_tittle" align="center" style="width:402px; ">To Get Access Please <a href="<?php echo urlForAdmin('user/login')?>">Log In</a></h2>
        
        <br clear="all" />
        
        
        
         <div align="center" class="err_div" style="width:425px; padding-top:75px; font-size:16px;"> <?php echo $err_msg ?> </div>
           
        <br clear="all"  />
        <div class="annanovas_new" style="padding-right:44px;padding-top:10px; padding-top:125px;">Copyright @ <a href="http://www.annanovas.com">AnnaNovas.COM</a></div>
      </div>
      <!--End of main_body_1-->
    </div>
    <!--End of main_body_1-->
  </div>
  <!--End of main_body-->
  <!--End of wrapper_block2-->
  <!--End of wrapper_block1-->
</div>

