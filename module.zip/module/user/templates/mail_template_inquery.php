
<table cellspacing="0" cellpadding="0" border="0" bgcolor="" align="center">
  <tbody>
    <tr>
      <td>
      	<span class="font11">Name:</span><br>
     		<div style="color: #0F8D81; width: 100%;" class="mylebel1" id="errordivname">
        	<?php echo $username; ?>
        </div>
       </td>
    </tr>
    <tr>
      <td>
   	  	<span class="font11">Email:</span><br>
    	  <div style="color: #0F8D81; display: block; width: 100%;" class="mylebel1" name="errordivemail" id="errordivemail">
        	<?php echo $email; ?>
        </div>
      </td>
    </tr>
    <tr>
      <td>
      	<span class="font11">Subject:</span><br>
      	<div style="color:#0F8D81; display: block; width: 100%;" class="mylebel1" name="errordivsubject" id="errordivsubject">
        	<?php echo $subject; ?>
        </div>
      </td>
    </tr>
    <tr>
      <td>
      	<span class="font11">Query:</span><br>
      	<div style="color: #0F8D81; display: block; width: 100%;" class="mylebel1" name="errordivquery" id="errordivquery">
        	<?php echo $query; ?>
        </div>
      </td>
    </tr>
  </tbody>
</table>