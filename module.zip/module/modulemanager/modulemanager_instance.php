<?php
require_once ('modulemanager.php');

//$protocols = array('Math', 'Content');
//initProtocols ($protocol_path, $protocols);

class modulemanager_instance extends modulemanager
{ 
		
}

?>