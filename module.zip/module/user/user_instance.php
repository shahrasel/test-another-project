<?php
require_once ('user.php');

//$protocols = array('Math', 'content');
//initProtocols ($protocol_path, $protocols);

class user_instance extends user
{ 
		
}

?>