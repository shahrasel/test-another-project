<?php
require_once ('adminnavigation.php');

class adminnavigation_instance extends adminnavigation
{
   		
}

?>