<?php
require_once ('ajax.php');

class ajax_instance extends ajax 
{	
		
}
?>