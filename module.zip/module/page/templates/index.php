<?php $row_data; ?>


<html>
<head>

</head>
<body>

<div>
	
    <div>
    	<a href="<?php echo getConfigValue('base_url')?>send/confirmationmial/requestupdate/getUpdate?report_price=12&brand=Mack&size=0,5 litre&report_day=Sunday&from_email=mhkhan@annanovas.com&pub_id=1017&pub_name=Barmuda&no_of_brand=25"><?php echo 'Update Beer Price'; ?></a>
    </div>
    <div>
    	<a href="<?php echo getConfigValue('base_url')?>plist/pub/getPlist?pub_id=10"><?php echo 'Beer-Price Plist'; ?></a>
    </div>
</div>

</body>
</html>
