function test(){
	alert('testing js');
}