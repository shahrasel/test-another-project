<?php
require_once ('pushnotification.php');

class pushnotification_instance extends pushnotification 
{	
		
}
?>