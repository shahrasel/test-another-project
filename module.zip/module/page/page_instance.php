<?php
require_once ('page.php');

class page_instance extends page 
{	
		
}
?>